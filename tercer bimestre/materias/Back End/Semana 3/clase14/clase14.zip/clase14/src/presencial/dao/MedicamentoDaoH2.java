package presencial.dao;

import presencial.modelo.Medicamento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class MedicamentoDaoH2 implements IDao<Medicamento>{
    private static final String SQL_INSERT="INSERT INTO MEDICAMENTOS (" +
            "id, nombre, laboratorio, cantidad,precio) VALUES (?,?,?,?,?)";
    @Override
    public Medicamento guardar(Medicamento medicamento) {
        //conectarnos a la base y guardar el medicamento
        Connection connection=null;

        try{
            Class.forName("org.h2.Driver");
            connection= DriverManager.getConnection("jdbc:h2:~/clase14","sa","sa");
            PreparedStatement ps= connection.prepareStatement(SQL_INSERT);
            ps.setInt(1,medicamento.getId());
            ps.setString(2,medicamento.getNombre());
            ps.setString(3,medicamento.getLaboratorio());
            ps.setInt(4,medicamento.getCantidad());
            ps.setDouble(5,medicamento.getPrecio());
            ps.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return medicamento;

    }
}
