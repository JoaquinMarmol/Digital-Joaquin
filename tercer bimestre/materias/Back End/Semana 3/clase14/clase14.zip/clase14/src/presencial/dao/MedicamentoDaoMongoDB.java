package presencial.dao;

import presencial.modelo.Medicamento;

public class MedicamentoDaoMongoDB implements IDao<Medicamento> {
    @Override
    public Medicamento guardar(Medicamento medicamento) {

        return null;
    }
}
